Drivers: LG_Mobile_MAC_Driver
Version: 5.2	
UNINSTALL:

If this driver causes problems, or if you would like to Uninstall, reboot the machine with no USB devices plugged in

 1. Run uninstall provided with the package

Then, reboot again...

